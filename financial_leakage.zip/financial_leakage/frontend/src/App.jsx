import { useCallback, useEffect, useState } from "react";

import Sidebar from "./components/sidebar";
import Header from "./components/header";
import TransactionForm from "./components/TransactionForm";

import Dashboard from "./pages/Dashboard";
import Transactions from "./pages/Transactions";
import Alerts from "./pages/Alerts";

import {
  getTransactions,
  getAlerts,
  getDashboardSummary,
  createTransaction as createTransactionAPI,
  updateAlertStatus as updateAlertStatusAPI,
} from "./services/api";

import "./App.css";

function App() {
  const [transactions, setTransactions] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [summary, setSummary] = useState({
    total_transactions: 0,
    total_alerts: 0,
    new_alerts: 0,
    confirmed_alerts: 0,
  });

  const [page, setPage] = useState("Dashboard");
  const [showForm, setShowForm] = useState(false);

  const [vendor, setVendor] = useState("");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState("2026-10-29");
  const [reference, setReference] = useState("");
  const [currency, setCurrency] = useState("INR");
  const [description, setDescription] = useState("");
  const [search, setSearch] = useState("");

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadData = useCallback(async () => {
    try {
      setError("");

      const [transactionData, alertData, summaryData] =
        await Promise.all([
          getTransactions(),
          getAlerts(),
          getDashboardSummary(),
        ]);

      // Convert backend fields to the fields used by our React components.
      setTransactions(
        transactionData.map((item) => ({
          id: item.id,
          reference_number: item.reference_number,
          vendor: item.vendor_name,
          date: item.transaction_date,
          amount: Number(item.amount),
          currency: item.currency,
          description: item.description,
          status: "Normal",
        }))
      );

      setAlerts(alertData);
      setSummary(summaryData);
    } catch (err) {
      setError(
        `${err.message}. Check that FastAPI and PostgreSQL are running.`
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  async function handleCreateTransaction(event) {
    event.preventDefault();

    try {
      setError("");

      await createTransactionAPI({
        reference_number: reference.trim(),
        vendor_name: vendor.trim(),
        transaction_date: date,
        amount: amount,
        currency: currency,
        description: description.trim() || null,
      });

      setVendor("");
      setAmount("");
      setReference("");
      setCurrency("INR");
      setDescription("");
      setShowForm(false);

      await loadData();
      setPage("Transactions");
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleUpdateStatus(alertId, reviewStatus) {
    try {
      setError("");
      await updateAlertStatusAPI(alertId, reviewStatus);
      await loadData();
    } catch (err) {
      setError(err.message);
    }
  }

  const normalizedAlerts = alerts.map((alert) => ({
    id: alert.id,
    transaction_id: alert.transaction_id,
    vendor:
      transactions.find((item) => item.id === alert.transaction_id)?.vendor ||
      `Transaction #${alert.transaction_id}`,
    date:
      transactions.find((item) => item.id === alert.transaction_id)?.date ||
      "",
    amount:
      transactions.find((item) => item.id === alert.transaction_id)?.amount ||
      0,
    status: alert.alert_type,
    review_status: alert.review_status,
    explanation: alert.explanation,
  }));

  const filteredTransactions = transactions.filter((transaction) =>
    `${transaction.reference_number} ${transaction.vendor} ${transaction.status}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  return (
    <div className="app-shell">
      <Sidebar
        page={page}
        setPage={setPage}
        alertCount={summary.new_alerts}
      />

      <main className="main-content">
        <Header page={page} />

        <section className="page-heading">
          <div>
            <p className="eyebrow">FINANCIAL CONTROL CENTER</p>
            <h1>{page}</h1>

            <p className="subheading">
              {page === "Dashboard"
                ? "Monitor transactions and identify potential financial leakage."
                : page === "Transactions"
                  ? "Review and manage financial transactions."
                  : "Investigate potential leakage indicators."}
            </p>
          </div>

          <button
            className="primary-button"
            onClick={() => setShowForm((previous) => !previous)}
          >
            + Add transaction
          </button>
        </section>

        {error && (
          <div className="notice">
            <div>
              <strong>Something went wrong</strong>
              <p>{error}</p>
              <button className="text-button" onClick={loadData}>
                Retry
              </button>
            </div>
          </div>
        )}

        {loading && <p>Loading data from the database...</p>}

        {showForm && (
          <form
            className="transaction-form"
            onSubmit={handleCreateTransaction}
          >
            <h3>Add a transaction</h3>

            <div className="form-grid">
              <label>
                Transaction reference
                <input
                  required
                  value={reference}
                  onChange={(event) => setReference(event.target.value)}
                  placeholder="e.g. TXN-10003"
                />
              </label>

              <label>
                Vendor name
                <input
                  required
                  value={vendor}
                  onChange={(event) => setVendor(event.target.value)}
                  placeholder="Enter vendor name"
                />
              </label>

              <label>
                Amount
                <input
                  required
                  type="number"
                  min="0.01"
                  step="0.01"
                  value={amount}
                  onChange={(event) => setAmount(event.target.value)}
                  placeholder="Enter amount"
                />
              </label>

              <label>
                Currency
                <select
                  value={currency}
                  onChange={(event) => setCurrency(event.target.value)}
                >
                  <option value="INR">INR</option>
                  <option value="USD">USD</option>
                  <option value="EUR">EUR</option>
                  <option value="GBP">GBP</option>
                </select>
              </label>

              <label>
                Transaction date
                <input
                  required
                  type="date"
                  value={date}
                  onChange={(event) => setDate(event.target.value)}
                />
              </label>

              <label>
                Description
                <input
                  value={description}
                  onChange={(event) => setDescription(event.target.value)}
                  placeholder="Optional description"
                />
              </label>
            </div>

            <p className="form-hint">
              Transactions are saved in PostgreSQL. Detection results are
              potential indicators and require review.
            </p>

            <button className="primary-button" type="submit">
              Save transaction
            </button>

            <button
              className="secondary-button"
              type="button"
              onClick={() => setShowForm(false)}
            >
              Cancel
            </button>
          </form>
        )}

        {!loading && page === "Dashboard" && (
  <Dashboard
    transactions={transactions}
    alerts={normalizedAlerts}
    summary={summary}
    setPage={setPage}
  />
)}

        {!loading && page === "Transactions" && (
          <Transactions
            transactions={filteredTransactions}
            search={search}
            setSearch={setSearch}
          />
        )}

        {!loading && page === "Alerts" && (
          <Alerts
            alerts={normalizedAlerts}
            updateStatus={handleUpdateStatus}
          />
        )}

        <footer>
          FinGuard · Financial Leakage Detection · Database-connected prototype
        </footer>
      </main>
    </div>
  );
}

export default App;