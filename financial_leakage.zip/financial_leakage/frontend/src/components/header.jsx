import "./../App.css";

function Header({ page }) {
  return (
    <header className="topbar">
      <div className="breadcrumb">
        Workspace <span>/</span> {page}
      </div>

      <div className="top-right">
        <span className="live-dot" />
        Demo mode
      </div>
    </header>
  );
}

export default Header;