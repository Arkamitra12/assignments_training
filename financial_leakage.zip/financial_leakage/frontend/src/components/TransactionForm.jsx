import "./../App.css";

function TransactionForm({
  vendor,
  setVendor,
  amount,
  setAmount,
  date,
  setDate,
  onSubmit,
  onCancel,
}) {
  return (
    <form className="transaction-form" onSubmit={onSubmit}>
      <h3>Add a transaction</h3>

      <div className="form-grid">
        <label>
          Vendor name
          <input
            required
            value={vendor}
            onChange={(event) => setVendor(event.target.value)}
            placeholder="Enter vendor name"
          />
        </label>

        <label>
          Amount (₹)
          <input
            required
            type="number"
            min="0.01"
            step="0.01"
            value={amount}
            onChange={(event) => setAmount(event.target.value)}
            placeholder="Enter amount"
          />
        </label>

        <label>
          Transaction date
          <input
            required
            type="date"
            value={date}
            onChange={(event) => setDate(event.target.value)}
          />
        </label>
      </div>

      <p className="form-hint">
        Demo rule: ₹1,00,000 or more is flagged as high value.
        A matching vendor, amount and date may indicate a duplicate.
      </p>

      <button className="primary-button" type="submit">
        Save transaction
      </button>

      <button
        className="secondary-button"
        type="button"
        onClick={onCancel}
      >
        Cancel
      </button>
    </form>
  );
}

export default TransactionForm;