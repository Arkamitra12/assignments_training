import "./../App.css";

function Sidebar({ page, setPage, alertCount }) {
  const menuItems = ["Dashboard", "Transactions", "Alerts"];

  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-icon">F</div>
        <div>
          <strong>FinGuard</strong>
          <small>Financial Intelligence</small>
        </div>
      </div>

      <p className="nav-label">WORKSPACE</p>

      {menuItems.map((item) => (
        <button
          key={item}
          className={`nav-item ${page === item ? "active" : ""}`}
          onClick={() => setPage(item)}
        >
          <span>
            {item === "Dashboard"
              ? "▦"
              : item === "Transactions"
                ? "↔"
                : "⚑"}
          </span>
          {item}

          {item === "Alerts" && (
            <b className="nav-count">{alertCount}</b>
          )}
        </button>
      ))}

      <div className="sidebar-bottom">
        <div className="avatar">FA</div>
        <div>
          <strong>Finance Analyst</strong>
          <small>Demo workspace</small>
        </div>
      </div>
    </aside>
  );
}

export default Sidebar;