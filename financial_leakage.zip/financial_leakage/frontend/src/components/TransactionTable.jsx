import "./../App.css";

function TransactionTable({ transactions, onStatusChange }) {
  if (transactions.length === 0) {
    return <p className="empty-state">No transactions found.</p>;
  }

  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>TRANSACTION ID</th>
            <th>VENDOR</th>
            <th>DATE</th>
            <th>AMOUNT</th>
            <th>STATUS</th>
            {onStatusChange && <th>REVIEW STATUS</th>}
          </tr>
        </thead>

        <tbody>
          {transactions.map((transaction) => (
            <tr key={transaction.id}>
              <td className="transaction-id">{transaction.id}</td>

              <td className="vendor-cell">{transaction.vendor}</td>

              <td>{transaction.date}</td>

              <td className="amount-cell">
                {transaction.amount.toLocaleString("en-IN", {
                  style: "currency",
                  currency: "INR",
                  maximumFractionDigits: 2,
                })}
              </td>

              <td>
                <span
                  className={`status ${
                    transaction.status === "Normal"
                      ? "normal"
                      : transaction.status === "Confirmed"
                        ? "confirmed"
                        : transaction.status === "Dismissed"
                          ? "dismissed"
                          : "warning"
                  }`}
                >
                  {transaction.status}
                </span>
              </td>

              {onStatusChange && (
                <td>
                  <select
                    aria-label={`Review ${transaction.id}`}
                    value={transaction.status}
                    onChange={(event) =>
                      onStatusChange(
                        transaction.id,
                        event.target.value
                      )
                    }
                  >
                    <option value="Possible Duplicate">
                      Possible Duplicate
                    </option>
                    <option value="High Value">High Value</option>
                    <option value="Under Review">Under Review</option>
                    <option value="Confirmed">Confirmed</option>
                    <option value="Dismissed">Dismissed</option>
                    <option value="Normal">Normal</option>
                  </select>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default TransactionTable;