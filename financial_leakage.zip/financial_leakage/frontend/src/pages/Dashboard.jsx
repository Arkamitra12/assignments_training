
import StatCard from "../components/StatCard";
import TransactionTable from "../components/TransactionTable";
import "./../App.css";

function Dashboard({ transactions, alerts, summary, setPage }) {
  const highValueCount = alerts.filter(
    (alert) => alert.status === "High Value"
  ).length;

  const duplicateCount = alerts.filter(
    (alert) => alert.status === "Possible Duplicate"
  ).length;

  return (
    <>
      <div className="notice">
        <span>ⓘ</span>
        <div>
          <strong>Welcome to FinGuard</strong>
          <p>
            Live transaction data is loaded from PostgreSQL.
            A flagged transaction is not proof of fraud or financial loss.
          </p>
        </div>
      </div>

      <div className="stats-grid">
        <StatCard
          label="Total transactions"
          value={summary?.total_transactions ?? transactions.length}
          detail="Transactions recorded"
          icon="↔"
        />

        <StatCard
          label="Flagged transactions"
          value={summary?.total_alerts ?? alerts.length}
          detail="Require further review"
          icon="⚑"
        />

        <StatCard
          label="High-value alerts"
          value={highValueCount}
          detail="Transactions meeting configured thresholds"
          icon="₹"
        />

        <StatCard
          label="Possible duplicates"
          value={duplicateCount}
          detail="Matching vendor, date and amount"
          icon="⧉"
        />
      </div>

      <section className="panel">
        <div className="panel-heading">
          <div>
            <h2>Recent transactions</h2>
            <p>Latest recorded activity</p>
          </div>

          <button
            className="text-button"
            onClick={() => setPage("Transactions")}
          >
            View all →
          </button>
        </div>

        <TransactionTable transactions={transactions.slice(0, 5)} />
      </section>

      <section className="panel">
        <div className="panel-heading">
          <div>
            <h2>Items requiring attention</h2>
            <p>Potential issues to investigate</p>
          </div>

          <button
            className="text-button"
            onClick={() => setPage("Alerts")}
          >
            View alerts →
          </button>
        </div>

        <TransactionTable transactions={alerts.slice(0, 3)} />
      </section>
    </>
  );
}

export default Dashboard;
