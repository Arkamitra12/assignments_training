import TransactionTable from "../components/TransactionTable";
import "./../App.css";

function Alerts({ alerts, updateStatus }) {
  return (
    <section className="panel">
      <div className="panel-heading">
        <div>
          <h2>Flagged transactions</h2>
          <p>Review potential leakage indicators</p>
        </div>
      </div>

      <TransactionTable
        transactions={alerts}
        onStatusChange={updateStatus}
      />

      <p className="form-hint">
        A flag indicates a potential issue, not confirmed fraud
        or financial loss.
      </p>
    </section>
  );
}

export default Alerts;