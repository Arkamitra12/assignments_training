import TransactionTable from "../components/TransactionTable";
import "./../App.css";

function Transactions({
  transactions,
  search,
  setSearch,
}) {
  const filteredTransactions = transactions.filter((transaction) =>
    `${transaction.id} ${transaction.vendor} ${transaction.status}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  return (
    <section className="panel">
      <div className="panel-heading">
        <div>
          <h2>All transactions</h2>
          <p>{transactions.length} records in this demo</p>
        </div>

        <input
          className="search-input"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search transactions..."
        />
      </div>

      <TransactionTable transactions={filteredTransactions} />
    </section>
  );
}

export default Transactions;