const API_BASE_URL = "http://127.0.0.1:8000/api";

// Get all transactions from PostgreSQL through FastAPI
export async function getTransactions() {
  const response = await fetch(`${API_BASE_URL}/transactions`);

  if (!response.ok) {
    throw new Error("Failed to load transactions");
  }

  return response.json();
}

// Get all alerts
export async function getAlerts() {
  const response = await fetch(`${API_BASE_URL}/alerts`);

  if (!response.ok) {
    throw new Error("Failed to load alerts");
  }

  return response.json();
}

// Get dashboard summary
export async function getDashboardSummary() {
  const response = await fetch(`${API_BASE_URL}/dashboard/summary`);

  if (!response.ok) {
    throw new Error("Failed to load dashboard summary");
  }

  return response.json();
}

// Save a new transaction
export async function createTransaction(transaction) {
  const response = await fetch(`${API_BASE_URL}/transactions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(transaction),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || "Failed to create transaction");
  }

  return response.json();
}

// Update an alert's review status
export async function updateAlertStatus(alertId, reviewStatus) {
  const response = await fetch(
    `${API_BASE_URL}/alerts/${alertId}/status?review_status=${encodeURIComponent(reviewStatus)}`,
    {
      method: "PATCH",
    }
  );

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || "Failed to update alert status");
  }

  return response.json();
}