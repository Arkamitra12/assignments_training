from decimal import Decimal

from sqlalchemy.orm import Session

from models import Alert, DetectionRule, Transaction


def detect_transaction_issues(
    db: Session,
    transaction: Transaction,
) -> list[Alert]:
    alerts = []

    normalized_vendor = transaction.vendor_name.strip().casefold()

    # Rule 1: Detect possible duplicate payments.
    existing_transactions = (
        db.query(Transaction)
        .filter(
            Transaction.id != transaction.id,
            Transaction.transaction_date == transaction.transaction_date,
            Transaction.amount == transaction.amount,
            Transaction.currency == transaction.currency,
        )
        .all()
    )

    for existing in existing_transactions:
        if existing.vendor_name.strip().casefold() == normalized_vendor:
            alerts.append(
                Alert(
                    transaction_id=transaction.id,
                    alert_type="Possible Duplicate",
                    explanation=(
                        "A transaction with the same normalized vendor name, "
                        "exact amount, currency and date already exists. "
                        f"Matching transaction reference: "
                        f"{existing.reference_number}."
                    ),
                    review_status="New",
                )
            )
            break

    # Rule 2: Check the configured high-value threshold for the currency.
    rule = (
        db.query(DetectionRule)
        .filter(
            DetectionRule.rule_type == "HIGH_VALUE",
            DetectionRule.currency == transaction.currency,
            DetectionRule.is_enabled.is_(True),
        )
        .first()
    )

    if (
        rule is not None
        and rule.threshold_amount is not None
        and transaction.amount >= Decimal(rule.threshold_amount)
    ):
        alerts.append(
            Alert(
                transaction_id=transaction.id,
                alert_type="High Value",
                explanation=(
                    f"Transaction amount {transaction.amount} "
                    f"{transaction.currency} meets or exceeds the configured "
                    f"threshold of {rule.threshold_amount} "
                    f"{transaction.currency}."
                ),
                review_status="New",
            )
        )

    return alerts