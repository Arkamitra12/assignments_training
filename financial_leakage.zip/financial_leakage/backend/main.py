from contextlib import asynccontextmanager

from fastapi import FastAPI, Depends, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import func, text
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.orm import Session

import models

from database import Base, engine, get_db
from models import Transaction, Alert, DetectionRule
from schemas import TransactionCreate, TransactionResponse, AlertResponse
from services.detection_service import detect_transaction_issues


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Ensure the database tables exist.
    Base.metadata.create_all(bind=engine)
    yield


app = FastAPI(
    title="Financial Leakage Detection API",
    description="Backend API for the FinGuard financial leakage detection system.",
    version="1.0.0",
    lifespan=lifespan,
)

# Allow the React development server to communicate with FastAPI.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def home():
    return {
        "message": "FinGuard API is running",
        "status": "success",
    }


@app.get("/health")
def health_check():
    return {"status": "healthy"}


@app.get("/health/database")
def database_health_check():
    try:
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))

        return {
            "status": "connected",
            "database": "financial_leakage_db",
        }

    except SQLAlchemyError:
        raise HTTPException(
            status_code=503,
            detail="Database connection failed.",
        )


@app.post(
    "/api/transactions",
    response_model=TransactionResponse,
    status_code=201,
)
def create_transaction(
    transaction_data: TransactionCreate,
    db: Session = Depends(get_db),
):
    # Normalize vendor names by trimming whitespace.
    vendor_name = transaction_data.vendor_name.strip()

    if not vendor_name:
        raise HTTPException(
            status_code=422,
            detail="Vendor name cannot be empty.",
        )

    currency = transaction_data.currency.strip().upper()

    if len(currency) != 3 or not currency.isalpha():
        raise HTTPException(
            status_code=422,
            detail="Currency must be a three-letter code, such as INR.",
        )

    # Prevent duplicate transaction reference numbers.
    existing_reference = (
        db.query(Transaction)
        .filter(
            Transaction.reference_number
            == transaction_data.reference_number.strip()
        )
        .first()
    )

    if existing_reference:
        raise HTTPException(
            status_code=409,
            detail="This transaction reference number already exists.",
        )

    transaction = Transaction(
        reference_number=transaction_data.reference_number.strip(),
        vendor_name=vendor_name,
        transaction_date=transaction_data.transaction_date,
        amount=transaction_data.amount,
        currency=currency,
        description=transaction_data.description,
    )

    try:
        db.add(transaction)
        db.flush()

        # Evaluate detection rules before committing.
        detected_alerts = detect_transaction_issues(db, transaction)

        for alert in detected_alerts:
            db.add(alert)

        db.commit()
        db.refresh(transaction)

        return transaction

    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=409,
            detail="A transaction with this reference number already exists.",
        )

    except Exception:
        db.rollback()
        raise


@app.get(
    "/api/transactions",
    response_model=list[TransactionResponse],
)
def list_transactions(
    search: str | None = Query(default=None, max_length=200),
    db: Session = Depends(get_db),
):
    query = db.query(Transaction)

    if search and search.strip():
        search_term = f"%{search.strip()}%"
        query = query.filter(
            (Transaction.reference_number.ilike(search_term))
            | (Transaction.vendor_name.ilike(search_term))
        )

    return query.order_by(Transaction.id.desc()).all()


@app.get(
    "/api/transactions/{transaction_id}",
    response_model=TransactionResponse,
)
def get_transaction(
    transaction_id: int,
    db: Session = Depends(get_db),
):
    transaction = db.query(Transaction).filter(
        Transaction.id == transaction_id
    ).first()

    if transaction is None:
        raise HTTPException(
            status_code=404,
            detail="Transaction not found.",
        )

    return transaction


@app.get(
    "/api/alerts",
    response_model=list[AlertResponse],
)
def list_alerts(
    review_status: str | None = None,
    db: Session = Depends(get_db),
):
    query = db.query(Alert)

    if review_status:
        allowed_statuses = {
            "New",
            "Under Review",
            "Confirmed",
            "Dismissed",
        }

        if review_status not in allowed_statuses:
            raise HTTPException(
                status_code=422,
                detail="Invalid review status.",
            )

        query = query.filter(Alert.review_status == review_status)

    return query.order_by(Alert.id.desc()).all()


@app.patch("/api/alerts/{alert_id}/status")
def update_alert_status(
    alert_id: int,
    review_status: str,
    db: Session = Depends(get_db),
):
    allowed_statuses = {
        "New",
        "Under Review",
        "Confirmed",
        "Dismissed",
    }

    if review_status not in allowed_statuses:
        raise HTTPException(
            status_code=422,
            detail=f"Status must be one of: {', '.join(sorted(allowed_statuses))}.",
        )

    alert = db.query(Alert).filter(Alert.id == alert_id).first()

    if alert is None:
        raise HTTPException(
            status_code=404,
            detail="Alert not found.",
        )

    alert.review_status = review_status
    db.commit()
    db.refresh(alert)

    return {
        "message": "Alert status updated successfully.",
        "alert_id": alert.id,
        "review_status": alert.review_status,
    }


@app.get("/api/dashboard/summary")
def dashboard_summary(db: Session = Depends(get_db)):
    total_transactions = db.query(func.count(Transaction.id)).scalar() or 0

    total_alerts = db.query(func.count(Alert.id)).scalar() or 0

    new_alerts = (
        db.query(func.count(Alert.id))
        .filter(Alert.review_status == "New")
        .scalar()
        or 0
    )

    confirmed_alerts = (
        db.query(func.count(Alert.id))
        .filter(Alert.review_status == "Confirmed")
        .scalar()
        or 0
    )

    return {
        "total_transactions": total_transactions,
        "total_alerts": total_alerts,
        "new_alerts": new_alerts,
        "confirmed_alerts": confirmed_alerts,
    }