from datetime import datetime

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    Column,
    Date,
    DateTime,
    ForeignKey,
    Integer,
    Numeric,
    String,
    Text,
)
from sqlalchemy.orm import relationship

from database import Base


class Transaction(Base):
    __tablename__ = "transactions"

    id = Column(Integer, primary_key=True, index=True)

    reference_number = Column(
        String(100),
        unique=True,
        nullable=False,
        index=True,
    )

    vendor_name = Column(
        String(200),
        nullable=False,
        index=True,
    )

    transaction_date = Column(
        Date,
        nullable=False,
        index=True,
    )

    amount = Column(Numeric(14, 2), nullable=False)

    currency = Column(String(3), nullable=False, default="INR")

    description = Column(Text, nullable=True)

    created_at = Column(
        DateTime,
        default=datetime.utcnow,
        nullable=False,
    )

    alerts = relationship(
        "Alert",
        back_populates="transaction",
        cascade="all, delete-orphan",
    )

    __table_args__ = (
        CheckConstraint("amount > 0", name="check_positive_amount"),
    )


class Alert(Base):
    __tablename__ = "alerts"

    id = Column(Integer, primary_key=True, index=True)

    transaction_id = Column(
        Integer,
        ForeignKey("transactions.id", ondelete="CASCADE"),
        nullable=False,
    )

    alert_type = Column(String(50), nullable=False)

    explanation = Column(Text, nullable=False)

    review_status = Column(
        String(30),
        nullable=False,
        default="New",
    )

    created_at = Column(
        DateTime,
        default=datetime.utcnow,
        nullable=False,
    )

    transaction = relationship(
        "Transaction",
        back_populates="alerts",
    )

    __table_args__ = (
        CheckConstraint(
            "review_status IN "
            "('New', 'Under Review', 'Confirmed', 'Dismissed')",
            name="check_alert_review_status",
        ),
    )


class DetectionRule(Base):
    __tablename__ = "detection_rules"

    id = Column(Integer, primary_key=True, index=True)

    rule_name = Column(String(100), nullable=False)

    rule_type = Column(String(50), nullable=False)

    currency = Column(String(3), nullable=False, default="INR")

    threshold_amount = Column(Numeric(14, 2), nullable=True)

    is_enabled = Column(Boolean, nullable=False, default=True)

    created_at = Column(
        DateTime,
        default=datetime.utcnow,
        nullable=False,
    )