 
function EventCard({ event, availableSeats, onRegister }) {
  return (
    <div className="event-card">
 
      <div className="event-top">
        <span className="event-category">
          {event.category}
        </span>
 
        <span className="event-id">
          {event.id}
        </span>
      </div>
 
      <h3>{event.title}</h3>
 
      <p>📅 Date: {event.date}</p>
 
      <p>🕒 Time: {event.time}</p>
 
      <p>Total Seats: {event.capacity}</p>
 
      <p>
        Available Seats: <strong>{availableSeats}</strong>
      </p>
 
      <button
        onClick={() => onRegister(event)}
        disabled={availableSeats === 0}
      >
        {availableSeats === 0 ? "Fully Booked" : "Register"}
      </button>
 
    </div>
  );
}
 
export default EventCard;
 