import { useState } from "react";
 
function RegisterForm({ event, onSubmit, onClose }) {
 
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [errors, setErrors] = useState({});
 
  const handleSubmit = (e) => {
    e.preventDefault();
 
    let newErrors = {};
 
    if (!name.trim()) {
      newErrors.name = "Name is required";
    }
 
    if (!email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      newErrors.email = "Enter a valid email address";
    }
 
    setErrors(newErrors);
 
    if (Object.keys(newErrors).length === 0) {
      onSubmit({
        name: name.trim(),
        email: email.trim(),
        eventId: event.id,
        registrationDate: new Date().toISOString()
      });
 
      setName("");
      setEmail("");
    }
  };
 
  return (
    <div className="form-container">
 
      <h2>Register for Event</h2>
 
      <h3>{event.title}</h3>
 
      <form onSubmit={handleSubmit}>
 
        <label>Full Name</label>
 
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter your name"
        />
 
        {errors.name && <p className="error">{errors.name}</p>}
 
        <label>Email Address</label>
 
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Enter your email"
        />
 
        {errors.email && <p className="error">{errors.email}</p>}
 
        <button type="submit">Confirm Registration</button>
 
        <button type="button" onClick={onClose}>
          Cancel
        </button>
 
      </form>
 
    </div>
  );
}
 
export default RegisterForm;
 