import { BrowserRouter, Routes, Route } from "react-router-dom";
 
import Navbar from "./components/Navbar";
import Events from "./pages/Events";
import Registrations from "./pages/Registrations";
 
import { EventProvider } from "./context/EventContext";
 
function App() {
 
  return (
 
    <EventProvider>
 
      <BrowserRouter>
 
        <Navbar />
 
        <Routes>
 
          <Route path="/" element={<Events />} />
 
          <Route
            path="/registrations"
            element={<Registrations />}
          />
 
        </Routes>
 
      </BrowserRouter>
 
    </EventProvider>
 
  );
}
 
export default App;
 