const products = [

  { id: 1, name: "Wireless Headphones", category: "Electronics" ,price:9000, image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTSQnMqig559hTK4AE3nK57laCC7BMzA50zAALjJfsCrg&s=10"},
  { id: 3, name: "Running Shoes", category: "Fashion", price: 1799, image: "https://assets.sheinindia.in/medias/shein_sys_master/root1/20260716/2gI3/6a587ec2a2fc3a50f6dd1058/-473Wx593H-443344497-blue-MODEL5.jpg" },

  { id: 4, name: "Travel Backpack", category: "Fashion", price: 999, image: "https://rukminim2.flixcart.com/image/1266/1266/xif0q/backpack/h/r/f/18-0-travel-backpack-for-men-women-water-resistant-cabin-bag-resized-original-imahmuzxm3bpn5zz.jpeg?q=90" },

  { id: 5, name: "Bluetooth Speaker", category: "Electronics", price: 1299, image: "https://shopatsc.com/cdn/shop/files/Image1_2075808d-9adb-4431-8f14-d539c6230875_1024x1024@2x.jpg?v=1750080146" },

  { id: 6, name: "Water Bottle", category: "Home", price: 499, image: "https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcT7M2uIBI7EMPRi3UqC10u898YXR0IUZMQVHWotX4poUY45s9M9KuRDgODeGfG_nGMLyl0_DNOceyYg1RIDe8XHy8wKm4Yh50pMsubZwZzrmrV4VOFFTPMWoA" },

  { id: 7, name: "Desk Lamp", category: "Home", price: 899, image: "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcRJQ2VypacyQiqcy4VH2ZkQ-ChAjaXdtUdlp03Ns5FIoo7Y29zCt8n1EnnCiJNS7op6I1UsCjqhq1wB_XPoxbIAOUcIYMWwegzSEexmDN_Y8LVmrtnT1pjE" },

  { id: 8, name: "Cotton T-Shirt", category: "Fashion", price: 599, image: "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcQjf8DV2yQO3-GrChvdpteoX5WxaQrSONCa6yPM6HsNzi6OityCYmSSJXEjwqnbg8R4uSQuxSv2t80XcTjSL1NEbfmTSlxkxx3RmTq-l4M2gDWp7X6a0oKf" },

];

export default products;
 