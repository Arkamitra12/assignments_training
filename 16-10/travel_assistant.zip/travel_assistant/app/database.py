import sqlite3

import uuid

from pathlib import Path

from datetime import datetime

# Database location

DB_PATH = Path(__file__).resolve().parent / "travel.db"
print("DATABASE LOCATION:",DB_PATH)


# =====================================

# 1. DATABASE CONNECTION

# =====================================

def get_connection():
    conn = sqlite3.connect(DB_PATH)

    conn.row_factory = sqlite3.Row

    return conn


# =====================================

# 2. INITIALIZE DATABASE

# =====================================

def initialize_database():
    conn = get_connection()

    cursor = conn.cursor()

    cursor.execute("""

                   CREATE TABLE IF NOT EXISTS trips
                   (

                       trip_id
                       TEXT
                       PRIMARY
                       KEY,

                       employee_id
                       TEXT
                       NOT
                       NULL,

                       destination
                       TEXT
                       NOT
                       NULL,

                       start_date
                       TEXT
                       NOT
                       NULL,

                       end_date
                       TEXT
                       NOT
                       NULL,

                       purpose
                       TEXT
                       NOT
                       NULL,

                       status
                       TEXT
                       DEFAULT
                       'Booked',

                       created_at
                       TEXT

                   )

                   """)

    conn.commit()

    conn.close()

    print("SQLite database initialized successfully!")


# =====================================

# 3. CREATE A NEW TRIP

# =====================================

def create_trip(employee_id, destination,

                start_date, end_date, purpose):
    trip_id = "TRIP-" + str(uuid.uuid4())[:8].upper()

    conn = get_connection()

    cursor = conn.cursor()

    cursor.execute("""

                   INSERT INTO trips (trip_id,
                                      employee_id,
                                      destination,
                                      start_date,
                                      end_date,
                                      purpose,
                                      status,
                                      created_at)

                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)

                   """, (

                       trip_id,

                       employee_id,

                       destination,

                       start_date,

                       end_date,

                       purpose,

                       "Booked",

                       datetime.now().isoformat()

                   ))

    conn.commit()

    conn.close()

    return trip_id


# =====================================

# 4. RETRIEVE TRIP BY ID

# =====================================

def get_trip_by_id(trip_id):
    conn = get_connection()

    cursor = conn.cursor()

    cursor.execute(

        "SELECT * FROM trips WHERE trip_id = ?",

        (trip_id,)

    )

    trip = cursor.fetchone()

    conn.close()

    return dict(trip) if trip else None


# =====================================

# 5. RETRIEVE EMPLOYEE TRIPS

# =====================================

def get_employee_trips(employee_id):
    conn = get_connection()

    cursor = conn.cursor()

    cursor.execute(

        "SELECT * FROM trips WHERE employee_id = ?",

        (employee_id,)

    )

    trips = cursor.fetchall()

    conn.close()

    return [dict(trip) for trip in trips]
