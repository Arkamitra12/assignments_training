
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from datetime import date

from app.database import (
    initialize_database,
    create_trip,
    get_trip_by_id,
    get_employee_trips
)

from services.assistant import generate_travel_advisory


# ==========================================
# 1. REQUEST MODELS
# ==========================================

class TripRequest(BaseModel):
    employee_id: str
    destination: str
    start_date: date
    end_date: date
    purpose: str


class ChatRequest(BaseModel):
    session_id: str
    trip_id: str
    question: str


# ==========================================
# 2. FASTAPI APPLICATION
# ==========================================

app = FastAPI(
    title="AI Travel and Weather Advisory Assistant",
    description="Employee Business Travel Management API",
    version="1.0"
)


# ==========================================
# 3. DATABASE INITIALIZATION
# ==========================================

@app.on_event("startup")
def startup():
    initialize_database()


# ==========================================
# 4. HOME ENDPOINT
# ==========================================

@app.get("/")
def home():
    return {
        "message": "Welcome to AI Travel and Weather Advisory Assistant"
    }


# ==========================================
# 5. CREATE TRIP
# ==========================================

@app.post("/trips")
def register_trip(trip: TripRequest):

    if trip.end_date < trip.start_date:
        raise HTTPException(
            status_code=400,
            detail="End date cannot be before start date"
        )

    if trip.end_date < date.today():
        raise HTTPException(
            status_code=400,
            detail="Trip dates cannot be entirely in the past"
        )

    trip_id = create_trip(
        employee_id=trip.employee_id,
        destination=trip.destination,
        start_date=trip.start_date.isoformat(),
        end_date=trip.end_date.isoformat(),
        purpose=trip.purpose
    )

    return {
        "message": "Trip registered successfully",
        "trip_id": trip_id
    }


# ==========================================
# 6. GET TRIP BY ID
# ==========================================

@app.get("/trips/{trip_id}")
def retrieve_trip(trip_id: str):

    trip = get_trip_by_id(trip_id)

    if not trip:
        raise HTTPException(
            status_code=404,
            detail="Trip not found"
        )

    return trip


# ==========================================
# 7. GET EMPLOYEE TRIPS
# ==========================================

@app.get("/employees/{employee_id}/trips")
def retrieve_employee_trips(employee_id: str):

    trips = get_employee_trips(employee_id)

    return {
        "employee_id": employee_id,
        "total_trips": len(trips),
        "trips": trips
    }


# ==========================================
# 8. AI TRAVEL CHAT ENDPOINT
# ==========================================

@app.post("/chat")
def chat_with_assistant(request: ChatRequest):

    try:

        answer = generate_travel_advisory(
            trip_id=request.trip_id,
            question=request.question,
            session_id=request.session_id
        )

        if answer.startswith("Assistant Error:"):
            raise HTTPException(
                status_code=500,
                detail=answer
            )

        return {
            "session_id": request.session_id,
            "trip_id": request.trip_id,
            "question": request.question,
            "answer": answer
        }

    except HTTPException:
        raise

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )
