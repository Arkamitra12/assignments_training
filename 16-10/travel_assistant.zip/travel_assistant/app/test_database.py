from database import (

    initialize_database,

    create_trip,

    get_trip_by_id,

    get_employee_trips

)

# Initialize database

initialize_database()

# Create sample trip

trip_id = create_trip(

    employee_id="EMP104",

    destination="Jaipur",

    start_date="2026-11-20",

    end_date="2026-11-23",

    purpose="Client meeting"

)

print("\nCreated Trip ID:", trip_id)

# Retrieve trip

trip = get_trip_by_id(trip_id)

print("\nRetrieved Trip:")

print(trip)

# Retrieve employee trips

all_trips = get_employee_trips("EMP104")

print("\nEmployee Trips:")

print(all_trips)
