from langchain_core.tools import tool

from app.database import get_trip_by_id


@tool
def retrieve_trip_tool(trip_id: str) -> dict:
    """Retrieve an employee trip from SQLite."""

    print("Looking for Trip ID:", trip_id)

    trip = get_trip_by_id(trip_id)

    if not trip:
        print("Trip not found in database!")

        return {"error": f"No trip found with ID {trip_id}"}

    print("Trip successfully retrieved:", trip)

    return trip
