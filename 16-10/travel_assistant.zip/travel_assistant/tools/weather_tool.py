import requests

from datetime import date, timedelta


# =====================================

# 1. GET LOCATION COORDINATES

# =====================================

def get_coordinates(city):
    url = "https://geocoding-api.open-meteo.com/v1/search"

    params = {

        "name": city,

        "count": 1,

        "language": "en",

        "format": "json"

    }

    response = requests.get(

        url,

        params=params,

        timeout=15

    )

    response.raise_for_status()

    data = response.json()

    if not data.get("results"):
        raise ValueError(f"Location not found: {city}")

    location = data["results"][0]

    return {

        "city": location["name"],

        "latitude": location["latitude"],

        "longitude": location["longitude"]

    }


# =====================================

# 2. GET WEATHER FORECAST

# =====================================

def get_weather_forecast(city):
    location = get_coordinates(city)

    url = "https://api.open-meteo.com/v1/forecast"

    params = {

        "latitude": location["latitude"],

        "longitude": location["longitude"],

        "daily": [

            "temperature_2m_max",

            "temperature_2m_min",

            "precipitation_probability_max",

            "weather_code"

        ],

        "timezone": "auto",

        "forecast_days": 16

    }

    response = requests.get(

        url,

        params=params,

        timeout=20

    )

    response.raise_for_status()

    data = response.json()

    daily = data.get("daily", {})

    forecast_dates = daily.get("time", [])

    if not forecast_dates:
        raise ValueError("Weather forecast unavailable")

    today = date.today()

    forecast = []

    for index, forecast_date in enumerate(forecast_dates):

        forecast_day = date.fromisoformat(forecast_date)

        # Ignore past dates

        if forecast_day < today:
            continue

        forecast.append({

            "date": forecast_date,

            "max_temperature":

                daily["temperature_2m_max"][index],

            "min_temperature":

                daily["temperature_2m_min"][index],

            "rain_probability":

                daily["precipitation_probability_max"][index],

            "weather_code":

                daily["weather_code"][index]

        })

    return {

        "location": location,

        "forecast": forecast

    }


# =====================================

# 3. TEST WEATHER TOOL

# =====================================

if __name__ == "__main__":

    try:

        result = get_weather_forecast("Jaipur")

        print("\nLOCATION:")

        print(result["location"])

        print("\nWEATHER FORECAST:")

        for day in result["forecast"]:
            print(day)

    except Exception as error:

        print("Weather API Error:", error)
from langchain_core.tools import tool


@tool
def weather_forecast_tool(city: str) -> dict:
    """

    Retrieve actual weather forecast for a city

    using the Open-Meteo API.

    """

    return get_weather_forecast(city)
