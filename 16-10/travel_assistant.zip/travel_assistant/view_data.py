import sqlite3

# Connect to SQLite database

conn = sqlite3.connect("app/travel.db")

cursor = conn.cursor()

# Show all tables

cursor.execute("""

               SELECT name
               FROM sqlite_master

               WHERE type = 'table';

               """)

tables = cursor.fetchall()

print("DATABASE TABLES:")

print(tables)

# Display records from each table

for table in tables:

    table_name = table[0]

    print(f"\n--- TABLE: {table_name} ---")

    cursor.execute(f'SELECT * FROM "{table_name}"')

    rows = cursor.fetchall()

    # Display column names

    columns = [description[0] for description in cursor.description]

    print(columns)

    for row in rows:
        print(row)

conn.close()
