from memory import (

    create_session,

    save_message,

    get_conversation_history,

    get_formatted_history

)

# Create session

session_id = create_session()

print("Session ID:", session_id)

# Save messages

save_message(

    session_id,

    "user",

    "I am travelling to Jaipur"

)

save_message(

    session_id,

    "assistant",

    "Have a wonderful trip!"

)

# Retrieve messages

print("\nConversation History:")

print(get_conversation_history(session_id))

# Formatted history

print("\nFormatted History:")

print(get_formatted_history(session_id))
