
import json
import uuid

from services.redis_client import redis_client


# =====================================
# CREATE SESSION
# =====================================

def create_session():
    return str(uuid.uuid4())


# =====================================
# SAVE MESSAGE
# =====================================

def save_message(session_id, role, content):

    key = f"travel_assistant:{session_id}"

    message = {
        "role": role,
        "content": content
    }

    redis_client.rpush(key, json.dumps(message))

    # Keep latest 20 messages
    redis_client.ltrim(key, -20, -1)

    # Expire after 24 hours
    redis_client.expire(key, 86400)


# =====================================
# GET CONVERSATION HISTORY
# =====================================

def get_conversation_history(session_id):

    key = f"travel_assistant:{session_id}"

    messages = redis_client.lrange(key, 0, -1)

    return [
        json.loads(message)
        for message in messages
    ]


# =====================================
# FORMAT HISTORY
# =====================================

def get_formatted_history(session_id):

    history = get_conversation_history(session_id)

    formatted = ""

    for message in history:

        formatted += (
            f"{message['role']}: "
            f"{message['content']}\n"
        )

    return formatted


# =====================================
# CLEAR SESSION
# =====================================

def clear_session(session_id):

    key = f"travel_assistant:{session_id}"

    redis_client.delete(key)

    print("Conversation memory cleared!")
