import json
from datetime import date, timedelta

from app.database import (
    DB_PATH,
    get_trip_by_id
)

from tools.trip_tool import retrieve_trip_tool
from tools.weather_tool import weather_forecast_tool

from services.llm import llm

from services.memory import (
    save_message,
    get_formatted_history
)

from langchain_core.prompts import ChatPromptTemplate


# ==========================================
# 1. LANGCHAIN PROMPT
# ==========================================

prompt = ChatPromptTemplate.from_messages([

    (
        "system",
        """
        You are an AI-powered Travel and Weather
        Advisory Assistant for business employees.

        Responsibilities:

        1. Provide advice based on saved trip details.
        2. Use actual weather information from tools.
        3. Never invent weather conditions or temperatures.
        4. Suggest suitable clothing and packing items.
        5. Provide 3-4 practical recommendations.
        6. Remember previous conversation context.
        7. Keep responses concise and professional.
        8. Clearly mention when weather information is unavailable.
        """
    ),

    (
        "human",
        """
        PREVIOUS CONVERSATION:

        {chat_history}

        EMPLOYEE TRIP DETAILS:

        {trip_details}

        ACTUAL WEATHER INFORMATION:

        {weather_details}

        EMPLOYEE QUESTION:

        {question}

        Generate a personalized travel advisory using
        the previous conversation when relevant.
        """
    )

])


# ==========================================
# 2. CONNECT PROMPT WITH OLLAMA
# ==========================================

travel_chain = prompt | llm


# ==========================================
# 3. MAIN TRAVEL ASSISTANT
# ==========================================

def generate_travel_advisory(
    trip_id,
    question,
    session_id=None
):

    try:

        # ======================================
        # STAGE 1: RETRIEVE TRIP
        # ======================================

        print("\n========== STAGE 1 ==========")

        print("Database location:", DB_PATH)
        print("Database exists:", DB_PATH.exists())

        print("Requested Trip ID:", trip_id)

        trip = get_trip_by_id(trip_id)

        if not trip:

            return f"Trip {trip_id} was not found in database."

        print("\nTrip retrieved successfully!")

        print("Employee:", trip["employee_id"])
        print("Destination:", trip["destination"])
        print("Start date:", trip["start_date"])
        print("End date:", trip["end_date"])

        # ======================================
        # STAGE 2: REDIS CONVERSATION MEMORY
        # ======================================

        print("\n========== STAGE 2 ==========")

        print("Retrieving conversation memory...")

        # Use a stable employee-specific session
        # unless a session ID is explicitly provided.

        if session_id is None:

            session_id = f"employee-{trip['employee_id']}"

        chat_history = get_formatted_history(session_id)

        print("Session ID:", session_id)

        if chat_history:

            print("Previous conversation found!")

            print(chat_history)

        else:

            print("No previous conversation found.")

        # ======================================
        # STAGE 3: WEATHER INFORMATION
        # ======================================

        print("\n========== STAGE 3 ==========")

        print("Retrieving weather information...")

        weather = weather_forecast_tool.invoke({

            "city": trip["destination"]

        })

        if isinstance(weather, str):

            try:

                weather = json.loads(weather)

            except json.JSONDecodeError:

                return "Weather API returned invalid data."

        if not isinstance(weather, dict):

            return "Weather information is unavailable."

        forecast = weather.get("forecast", [])

        if not forecast:

            return "No weather forecast is currently available."

        print("\nWeather retrieved successfully!")

        print("Weather location:", weather.get("location"))

        print("Forecast:", forecast)

        # ======================================
        # CHECK TRAVEL DATE AVAILABILITY
        # ======================================

        available_dates = {

            item["date"]

            for item in forecast

        }

        start_date = date.fromisoformat(trip["start_date"])

        end_date = date.fromisoformat(trip["end_date"])

        required_dates = set()

        current_date = start_date

        while current_date <= end_date:

            required_dates.add(current_date.isoformat())

            current_date += timedelta(days=1)

        missing_dates = required_dates - available_dates

        print("\nRequired trip dates:", sorted(required_dates))

        print("Missing forecast dates:", sorted(missing_dates))

        if missing_dates:

            print("Complete forecast unavailable.")

            return (
                "Complete weather forecast is unavailable "
                "for your entire travel period. "
                "Please check closer to departure."
            )

        # ======================================
        # STAGE 4: GENERATE AI ADVISORY
        # ======================================

        print("\n========== STAGE 4 ==========")

        print("Generating AI travel advisory...")

        response = travel_chain.invoke({

            "chat_history": chat_history,

            "trip_details": json.dumps(
                trip,
                indent=2
            ),

            "weather_details": json.dumps(
                weather,
                indent=2
            ),

            "question": question

        })

        answer = response.content

        print("\nAI response generated successfully!")

        # ======================================
        # STAGE 5: SAVE CONVERSATION TO REDIS
        # ======================================

        print("\n========== STAGE 5 ==========")

        print("Saving conversation to Redis...")

        save_message(
            session_id,
            "user",
            question
        )

        save_message(
            session_id,
            "assistant",
            answer
        )

        print("Conversation saved to Redis!")

        print("Session ID:", session_id)

        return answer

    except Exception as e:

        print("\n========== ASSISTANT ERROR ==========")

        print(str(e))

        return f"Assistant Error: {str(e)}"


# ==========================================
# 4. TEST THE ASSISTANT
# ==========================================

if __name__ == "__main__":

    answer = generate_travel_advisory(

        trip_id="TRIP-1FF0CD8E",

        question=(
            "What items did you recommend packing?"
        )

    )

    print("\n========== FINAL TRAVEL ADVISORY ==========\n")

    print(answer)

