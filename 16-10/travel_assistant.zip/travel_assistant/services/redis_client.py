
import redis

# Connect to Redis running in Docker
redis_client = redis.Redis(
    host="localhost",
    port=6379,
    db=0,
    decode_responses=True
)

# Test connection
try:
    redis_client.ping()
    print("Redis connected successfully!")

except redis.ConnectionError as e:
    print("Redis connection failed:", e)
