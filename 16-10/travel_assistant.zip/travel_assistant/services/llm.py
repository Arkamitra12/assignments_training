
from langchain_ollama import ChatOllama

# Connect to local Ollama model
llm = ChatOllama(
    model="qwen2.5:3b",
    base_url="http://localhost:11434",
    temperature=0.2,
    num_predict=128,
    keep_alive="10m"
)


def generate_response(prompt):

    try:
        print("Connecting to Ollama...")
        response = llm.invoke(prompt)

        print("Response generated successfully!")

        return response.content

    except Exception as e:
        print("LLM Error:", str(e))
        return None


if __name__ == "__main__":

    question = """
    An employee is travelling to Jaipur
    for a business meeting.

    Suggest three important things
    the employee should prepare for.
    """

    answer = generate_response(question)

    print("\nAI RESPONSE:\n")

    if answer:
        print(answer)
